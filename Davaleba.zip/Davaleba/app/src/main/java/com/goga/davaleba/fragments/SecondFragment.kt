package com.goga.davaleba.fragments

import androidx.fragment.app.Fragment
import com.goga.davaleba.R

class SecondFragment: Fragment(R.layout.fragment_second) {
}