package com.goga.davaleba.fragments

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.goga.davaleba.R
import com.goga.davaleba.adapter.FruitAdapter

class FirstFragment: Fragment(R.layout.fragment_first) {
    private lateinit var recyclerView: RecyclerView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        recyclerView = view.findViewById(R.id.recyclerView)

        val fruits = listOf("Apple", "Banana", "Cherry", "Date", "Elderberry", "Fig", "Grape")
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = FruitAdapter(fruits)
    }
}