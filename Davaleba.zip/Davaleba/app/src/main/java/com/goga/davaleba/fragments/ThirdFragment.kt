package com.goga.davaleba.fragments

import androidx.fragment.app.Fragment
import com.goga.davaleba.R

class ThirdFragment: Fragment(R.layout.fragment_third) {
}